﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_3
{
    using System;

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            // Nhập chuỗi từ bàn phím
            Console.WriteLine("Nhập vào một chuỗi (khoảng 20 từ): ");
            string inputString = Console.ReadLine();

            while (true)
            {
                // Nhập từ cần kiểm tra
                Console.WriteLine("Nhập từ bạn muốn kiểm tra (hoặc nhập 'exit' để thoát): ");
                string wordToCheck = Console.ReadLine();

                // Kiểm tra và thoát khỏi vòng lặp nếu nhập 'exit'
                if (wordToCheck.ToLower() == "exit") break;

                // Đếm số lần xuất hiện và kiểm tra
                int count = CountOccurrences(inputString, wordToCheck);

                if (count > 0)
                {
                    Console.WriteLine($"Từ '{wordToCheck}' xuất hiện {count} lần trong chuỗi.");
                    break;
                }
                else
                {
                    Console.WriteLine($"Từ '{wordToCheck}' không nằm trong chuỗi. Hãy thử lại.");
                }
            }
        }

        static int CountOccurrences(string inputString, string wordToCheck)
        {
            int count = 0;
            int index = 0;

            while ((index = inputString.IndexOf(wordToCheck, index, StringComparison.CurrentCultureIgnoreCase)) != -1)
            {
                count++;
                index += wordToCheck.Length;
            }

            return count;
        }
    }
}
