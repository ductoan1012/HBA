﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_1
{

class Program
        {
            static void Main()
            {
                Console.OutputEncoding = System.Text.Encoding.UTF8;
                Console.InputEncoding = System.Text.Encoding.UTF8;

                Console.WriteLine("Nhập họ và tên của bạn: ");
                string hoTen = Console.ReadLine();

                // Chuẩn hóa họ tên
                string hoTenChuanHoa = ChuanHoaHoTen(hoTen);

                Console.WriteLine("Họ và tên sau khi chuẩn hóa: " + hoTenChuanHoa);
            }

            static string ChuanHoaHoTen(string hoTen)
            {
                TextInfo textInfo = new CultureInfo("vi-VN", false).TextInfo;
                // Loại bỏ các khoảng trắng thừa và chuyển đổi chuỗi về dạng TitleCase (mỗi từ bắt đầu bằng chữ cái in hoa)
                hoTen = textInfo.ToTitleCase(hoTen.ToLower().Trim());

                // Thay thế các khoảng trắng đôi hoặc nhiều bằng một khoảng trắng đơn
                while (hoTen.Contains("  "))
                    hoTen = hoTen.Replace("  ", " ");

                return hoTen;
            }
        }

}


