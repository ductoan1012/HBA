﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTVn
{
    class ChuoiKyTu
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            Console.WriteLine("Nhập vào một chuỗi:");
            string chuoi = Console.ReadLine();

            // Tìm độ dài của chuỗi
            int doDaiChuoi = chuoi.Length;
            Console.WriteLine("Độ dài của chuỗi là: " + doDaiChuoi);

            // In chuỗi theo thứ tự ngược lại
            Console.WriteLine("Chuỗi theo chiều đảo ngược:");
            for (int i = chuoi.Length - 1; i >= 0; i--)
            {
                Console.Write(chuoi[i]);
            }
            Console.WriteLine();

            // Đếm số từ trong chuỗi
            int soTu = chuoi.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
            Console.WriteLine("Số từ trong chuỗi là: " + soTu);

            // Đếm số lượng các loại ký tự
            int soChuCai = 0, soChuSo = 0, soKyTuDacBiet = 0;
            foreach (char c in chuoi)
            {
                if (char.IsLetter(c)) soChuCai++;
                else if (char.IsDigit(c)) soChuSo++;
                else if (!char.IsWhiteSpace(c)) soKyTuDacBiet++;
            }
            Console.WriteLine($"Chữ cái: {soChuCai}, Chữ số: {soChuSo}, Ký tự đặc biệt: {soKyTuDacBiet}");

            // Đếm số nguyên âm và phụ âm
            int soNguyenAm = 0, soPhuAm = 0;
            foreach (char c in chuoi.ToLower())
            {
                if ("aeiou".Contains(c)) soNguyenAm++;
                else if (char.IsLetter(c)) soPhuAm++;
            }
            Console.WriteLine($"Nguyên âm: {soNguyenAm}, Phụ âm: {soPhuAm}");

            // Tìm ký tự xuất hiện nhiều nhất
            var kyTuXuatHienNhieuNhat = chuoi.GroupBy(c => c)
                                              .OrderByDescending(grp => grp.Count())
                                              .First().Key;
            Console.WriteLine("Ký tự xuất hiện nhiều nhất là: " + kyTuXuatHienNhieuNhat);

            Console.WriteLine("Nhập vào chuỗi thứ hai để so sánh:");
            string chuoiSoSanh = Console.ReadLine();
            Console.WriteLine("Hai chuỗi là " + (chuoi.Equals(chuoiSoSanh) ? "giống" : "không giống") + " nhau.");

            char[] mangKyTu = chuoi.ToCharArray();
            Array.Sort(mangKyTu);
            Console.WriteLine("Chuỗi sau khi sắp xếp các ký tự: " + new string(mangKyTu));

            // 12. Sắp xếp các chuỗi (Giả định rằng có một mảng chuỗi để sắp xếp)
            string[] mangChuoi = chuoi.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            Array.Sort(mangChuoi);
            Console.WriteLine("Mảng chuỗi sau khi sắp xếp: " + string.Join(", ", mangChuoi));

            // 13. Lấy chuỗi con từ một chuỗi đã cho
            Console.WriteLine("Nhập vào chỉ số bắt đầu và độ dài của chuỗi con:");
            int index = int.Parse(Console.ReadLine());
            int length = int.Parse(Console.ReadLine());
            string chuoiCon = chuoi.Substring(index, length);
            Console.WriteLine("Chuỗi con: " + chuoiCon);

            // 14. Kiểm tra chuỗi con trong chuỗi
            Console.WriteLine("Nhập vào chuỗi con cần kiểm tra:");
            string chuoiConKiemTra = Console.ReadLine();
            Console.WriteLine("Chuỗi chứa chuỗi con: " + chuoi.Contains(chuoiConKiemTra));

            // 15. Chuyển đổi chữ hoa thành chữ thường và ngược lại
            string chuoiHoa = chuoi.ToUpper();
            string chuoiThuong = chuoi.ToLower();
            Console.WriteLine("Chuỗi in hoa: " + chuoiHoa);
            Console.WriteLine("Chuỗi in thường: " + chuoiThuong);

            // 16. Kiểm tra username và password
            Console.WriteLine("Nhập username:");
            string username = Console.ReadLine();
            Console.WriteLine("Nhập password:");
            string password = Console.ReadLine();
            // Tiếp theo, bạn sẽ kiểm tra username và password với một nguồn dữ liệu hoặc một cách nào đó.

            // 17. Tìm kiếm vị trí của chuỗi con trong chuỗi đã cho
            int viTriChuoiCon = chuoi.IndexOf(chuoiConKiemTra);
            Console.WriteLine("Vị trí của chuỗi con trong chuỗi: " + (viTriChuoiCon >= 0 ? viTriChuoiCon.ToString() : "Không tìm thấy"));

            // 18. Kiểm tra chữ hoa, chữ thường
            bool coChuHoa = chuoi.Any(char.IsUpper);
            bool coChuThuong = chuoi.Any(char.IsLower);
            Console.WriteLine("Chuỗi có chứa chữ hoa: " + coChuHoa);
            Console.WriteLine("Chuỗi có chứa chữ thường: " + coChuThuong);

            // 19. Đếm số lần xuất hiện của chuỗi con trong một chuỗi
            int demSoLanXuatHien = chuoi.Split(new string[] { chuoiConKiemTra }, StringSplitOptions.None).Length - 1;
            Console.WriteLine("Số lần xuất hiện của chuỗi con: " + demSoLanXuatHien);

            // 20. Chèn chuỗi con vào vị trí xuất hiện lần đầu của một chuỗi con khác trong một chuỗi
            Console.WriteLine("Nhập chuỗi con cần chèn:");
            string chuoiConCanChen = Console.ReadLine();
            Console.WriteLine("Nhập chuỗi con mà sau đó chuỗi cần chèn vào:");
            string chuoiMucTieu = Console.ReadLine();
            int viTriChen = chuoi.IndexOf(chuoiMucTieu);
            if (viTriChen >= 0)
            {
                chuoi = chuoi.Insert(viTriChen, chuoiConCanChen);
            }
            Console.WriteLine("Chuỗi sau khi chèn: " + chuoi);
        }
    }
}
        




