﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_2
{
    internal class Program
    {

class ChuoiKyTu
        {
            static void Main()
            {
                // Tạo biến StringBuilder
                StringBuilder chuoiKyTu = new StringBuilder();

                // Thêm dữ liệu vào biến bằng Append
                chuoiKyTu.Append("Xin chào ");

                // Xóa dữ liệu, sau đó thêm dữ liệu bằng AppendFormat
                chuoiKyTu.Clear();
                chuoiKyTu.AppendFormat("{0} ngày mới!", "Chào mừng");

                // Chèn thêm dữ liệu vào giữa biến
                chuoiKyTu.Insert(12, " tốt lành");

                // Xóa dãy ký tự từ vị trí thứ 3 đến 5
                chuoiKyTu.Remove(2, 3);

                // Tìm và thay thế ký tự 'a' bằng ký tự 'e'
                chuoiKyTu.Replace('a', 'e');

                Console.WriteLine(chuoiKyTu.ToString());
            }
        }

    }
}

