﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Tau
{
    class BenTau
    {
        static int tongSoTauDaChuyenHang = 0;
        static Queue<string> hangDoiTau = new Queue<string>();
        static Random ngauNhien = new Random();

        static void Main(string[] args)
        {
            Thread luongDenCuaTau = new Thread(new ThreadStart(TauDen));
            Thread luongChuyenHangCuaTau = new Thread(new ThreadStart(ChuyenHang));

            luongDenCuaTau.Start();
            luongChuyenHangCuaTau.Start();
        }

        static void TauDen()
        {
            while (true)
            {
                Thread.Sleep(ngauNhien.Next(5000, 10001)); // Tau den cu sau 5-10 giay
                hangDoiTau.Enqueue("Tau " + (tongSoTauDaChuyenHang + hangDoiTau.Count + 1));
                Console.WriteLine("Tau moi den: Tong so tau dang doi chuyen hang la " + hangDoiTau.Count);
            }
        }

        static void ChuyenHang()
        {
            while (true)
            {
                if (hangDoiTau.Count > 0)
                {
                    Thread.Sleep(ngauNhien.Next(3000, 7001)); // Mat 3-7 giay de chuyen hang
                    string tau = hangDoiTau.Dequeue();
                    tongSoTauDaChuyenHang++;
                    Console.WriteLine(tau + " da chuyen hang xong. Tong so tau da chuyen hang la " + tongSoTauDaChuyenHang);
                }
            }
        }
    }
}