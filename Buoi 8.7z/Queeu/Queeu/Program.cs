﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queeu
{

    public class SinhVien
    {
        public string Ten { get; set; }
        public DateTime ThoiGianDenLop { get; set; }
    }

    public class QuanLySinhVien
    {
        private Queue<SinhVien> hangDoiSinhVien = new Queue<SinhVien>();

        public void NhapThongTinSinhVien()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Nhập tên sinh viên thứ " + (i + 1) + ":");
                string ten = Console.ReadLine();
                // Giả định thời gian đến lớp được nhập hoặc được xác định tự động
                DateTime thoiGianDenLop = DateTime.Now;

                hangDoiSinhVien.Enqueue(new SinhVien { Ten = ten, ThoiGianDenLop = thoiGianDenLop });
            }
        }

        public void HienThiDanhSach()
        {
            foreach (SinhVien sv in hangDoiSinhVien)
            {
                Console.WriteLine(sv.Ten + " - Thời gian đến: " + sv.ThoiGianDenLop.ToString("HH:mm:ss"));
            }
        }

        public void XoaSinhVienTheoTen(string ten)
        {
            int soLuongTruoc = hangDoiSinhVien.Count;
            hangDoiSinhVien = new Queue<SinhVien>(hangDoiSinhVien.Where(sv => sv.Ten != ten));
            if (hangDoiSinhVien.Count < soLuongTruoc)
            {
                Console.WriteLine("Đã xóa sinh viên có tên là " + ten);
            }
            else
            {
                Console.WriteLine("Không tìm thấy sinh viên có tên là " + ten);
            }
        }
    }

    class ChuongTrinh
    {
        static void Main(string[] args)
        {
            QuanLySinhVien quanLySinhVien = new QuanLySinhVien();
            quanLySinhVien.NhapThongTinSinhVien();
            quanLySinhVien.HienThiDanhSach();

            Console.WriteLine("Nhập tên sinh viên cần xóa:");
            string tenXoa = Console.ReadLine();
            quanLySinhVien.XoaSinhVienTheoTen(tenXoa);
        }
    }
}

