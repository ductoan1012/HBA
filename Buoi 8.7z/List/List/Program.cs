﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
    class ChuongTrinh
    {
        static void Main(string[] args)
        {
            List<int> danhSachSoNguyen = new List<int>();

            // Thêm 10 số nguyên vào danh sách
            danhSachSoNguyen.AddRange(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });

            // Hiển thị danh sách đảo ngược
            danhSachSoNguyen.Reverse();
            Console.WriteLine("Dãy đảo ngược:");
            foreach (int so in danhSachSoNguyen)
            {
                Console.Write(so + " ");
            }
            Console.WriteLine();

            // Tìm kiếm trong danh sách có số 5 hay không, nếu có thì xóa hết khỏi danh sách
            if (danhSachSoNguyen.Contains(5))
            {
                danhSachSoNguyen.RemoveAll(x => x == 5);
                Console.WriteLine("Đã xóa số 5 khỏi danh sách.");
            }
            else
            {
                Console.WriteLine("Không tìm thấy số 5 trong danh sách.");
            }

            // Sắp xếp lại danh sách theo thứ tự tăng dần
            danhSachSoNguyen.Sort();
            Console.WriteLine("Danh sách sắp xếp tăng dần:");
            foreach (int so in danhSachSoNguyen)
            {
                Console.Write(so + " ");
            }
            Console.WriteLine();

            // Sắp xếp lại danh sách theo thứ tự giảm dần
            danhSachSoNguyen.Sort((a, b) => b.CompareTo(a));
            Console.WriteLine("Danh sách sắp xếp giảm dần:");
            foreach (int so in danhSachSoNguyen)
            {
                Console.Write(so + " ");
            }
            Console.WriteLine();
        }
    }
}
