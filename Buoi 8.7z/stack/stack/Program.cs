﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stack
{

    class ChuongTrinh
    {
        static void Main(string[] args)
        {
            Stack<string> nganXep = new Stack<string>();

            // Thêm các giá trị vào Stack
            nganXep.Push("Nguyễn Văn A");
            nganXep.Push("Trần Thị B");
            nganXep.Push("Lê Văn C");

            // Hiển thị giá trị đầu Stack
            Console.WriteLine("Phần tử đầu của Stack: " + nganXep.Peek());

            // Hiển thị tất cả Stack ra màn hình
            Console.WriteLine("Tất cả các phần tử trong Stack:");
            foreach (string ten in nganXep)
            {
                Console.WriteLine(ten);
            }

            // Kiểm tra sự tồn tại một giá trị trong Stack
            string tenCanTim = "Trần Thị B";
            if (nganXep.Contains(tenCanTim))
            {
                Console.WriteLine("Phần tử " + tenCanTim + " có trong Stack.");
            }
            else
            {
                Console.WriteLine("Phần tử " + tenCanTim + " không có trong Stack.");
            }

            // Đẩy tất cả giá trị các phần tử của Stack ra một mảng
            string[] mangTen = nganXep.ToArray();
            Console.WriteLine("Các phần tử của Stack được đẩy ra mảng:");

            foreach (string ten in mangTen)
            {
                Console.WriteLine(ten);
            }

            // Xóa phần tử đầu Stack
            Console.WriteLine("Xóa phần tử đầu của Stack: " + nganXep.Pop());

            // Xóa tất cả Stack
            nganXep.Clear();
            Console.WriteLine("Đã xóa tất cả các phần tử trong Stack.");
        }
    }
}

